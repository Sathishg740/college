<?php
       $con= mysqli_connect('localhost','root','','useraccounts');

        if(mysqli_connect_error()){
            echo "not connected";
            exit();
        }
        



?>